
# Primeiros passos com Open IA e Node JS

Repo construído para o video tutorial no Youtube
https://www.youtube.com/watch?v=z_Ab9d24Oas

## Authors

- [@pedrosgmagalhaes](https://github.com/pedrosgmagalhaes/)


## Tech Stack

**Server:** Node JS, OpenIA


## License

[MIT](https://choosealicense.com/licenses/mit/)


## Suporte

- Linkedin: https://www.linkedin.com/in/pemagalhaes/
- YouTube: https://www.youtube.com/@ioralabs